# Copyright (c) 2021 Alex Forencich
# 
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.

# Ethernet MAC with FIFO timing constraints

proc constrain_eth_mac_fifo_inst { inst } {
    puts "Inserting timing constraints for ethernet MAC with FIFO instance $inst"

    # RX status sync
    set_data_delay -from [get_registers "$inst|rx_sync_reg_1_reg[*]"] -to [get_registers "$inst|rx_sync_reg_2_reg[*]"] -override -get_value_from_clock_period dst_clock_period -value_multiplier 0.8

    # TX status sync
    set_data_delay -from [get_registers "$inst|tx_sync_reg_1_reg[*]"] -to [get_registers "$inst|tx_sync_reg_2_reg[*]"] -override -get_value_from_clock_period dst_clock_period -value_multiplier 0.8
}
